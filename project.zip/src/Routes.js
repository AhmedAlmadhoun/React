// import React from 'react';
// import { Route, Switch } from 'react-router-dom';
// import LoginPage from './components/LoginPage';
// import ScrollingCards from './components/ScrollingCards';
// import SearchAndFilter from './components/SearchAndFilter';

// const Routes = () => {
//   return (
//     <Routes>
//       <Route exact path="/LoginPage" component={LoginPage} />
//       <Route path="/ScrollingCards" component={ScrollingCards} />
//       <Route path="/SearchAndFilter" component={SearchAndFilter} />
//       {/* يمكنك أضافة مسارات إضافية هنا إذا كنت ترغب */}
//     </Routes>
//   );
// };

// export default Routes;
